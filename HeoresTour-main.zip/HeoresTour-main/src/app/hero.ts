export interface Hero {
    id: number;
    name: string;
    pts: number;
  }