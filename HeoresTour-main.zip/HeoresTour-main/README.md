# Medina21

This project was generated with [Angular CLI](https://github.com/angular/angular-cli) version 11.2.9.

## Development

Visit [This page](http://medina21.s3-website-us-east-1.amazonaws.com/) for a live example 